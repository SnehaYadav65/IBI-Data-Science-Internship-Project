# 📊 IBI Data Science Internship Project

This project is a comprehensive analysis task completed as part of the IBI Internship, involving customer analytics, churn prediction, sales forecasting, and market basket analysis.

## Contents

- `IBI_DataScience_Project_Notebook.ipynb` — Full analysis notebook
- `Final_Report_With_Visuals.pdf` — Final report with visualizations
- Exploratory analysis, predictive modeling, ARIMA forecasting, and Apriori-based product association

## Key Tasks Completed
- Customer Segmentation (RFM + KMeans)
- Churn Prediction (Random Forest + ROC-AUC)
- Sales Forecasting (ARIMA model)
- Market Basket Analysis (Apriori algorithm)
- Strategic recommendations

---
Created by Sneha Yadav for IBI Internship (2025).
